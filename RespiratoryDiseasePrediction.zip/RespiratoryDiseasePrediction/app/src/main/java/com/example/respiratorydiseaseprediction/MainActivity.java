package com.example.respiratorydiseaseprediction;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button b1;
    private TextView t1,t2,t3,t4;
    private com.google.android.material.floatingactionbutton.FloatingActionButton fb1;
    private EditText e1,e2,e3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1= (TextView) findViewById(R.id.textView4);
        t2= (TextView) findViewById(R.id.textView3);
        t3= (TextView) findViewById(R.id.textView2);
        t4= (TextView) findViewById(R.id.textView);
        b1= (Button) findViewById(R.id.button);
        fb1= (com.google.android.material.floatingactionbutton.FloatingActionButton) findViewById(R.id.floatingActionButton);
        e1= (EditText) findViewById(R.id.editTextTextPersonName1);
        e2= (EditText) findViewById(R.id.editTextTextPersonName2);
        e3= (EditText) findViewById(R.id.editTextTextMultiLine);

        //b1.setOnContextClickListener();
    }
}